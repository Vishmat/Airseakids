# Air & Sea Kids

Application Android dédiée à une tablette enfant.

## Fonctions V1

- Flightradar24 dans une WebView
- MarineTraffic dans une WebView
- Navigation interne limitée aux domaines autorisés
- Aucun navigateur externe ouvert par les liens
- Minuteur quotidien
- PIN parent
- Réglage de la durée quotidienne
- Changement du PIN
- Préparation au mode kiosque Android / Lock Task
- Redémarrage automatique de l'application après démarrage Android

## Compilation

1. Installer Android Studio.
2. Ouvrir ce dossier comme projet.
3. Laisser Gradle télécharger les dépendances.
4. Brancher la tablette Android en USB avec le débogage USB activé.
5. Compiler et installer l'application.

## Mode kiosque

Pour un vrai verrouillage de tablette, l'application doit être provisionnée comme
application autorisée en mode Lock Task (idéalement comme Device Owner sur une
tablette dédiée). La procédure exacte dépend du modèle et de la version Android.

Exemple de provisionnement de développement via ADB, uniquement sur une tablette
réinitialisée et dédiée :

adb shell dpm set-device-owner fr.airseakids/.AdminReceiver

L'application déclare un DeviceAdminReceiver. Pour un vrai mode kiosque administré,
il faut toutefois provisionner la tablette comme Device Owner. Sur une tablette
réinitialisée et dédiée, la commande de développement typique est :

adb shell dpm set-device-owner fr.airseakids/.AdminReceiver

Cette étape efface/initialise généralement l'état de gestion de l'appareil : ne la
fait pas sur une tablette contenant des données personnelles. Les procédures peuvent
varier selon le fabricant et la version Android.

## Important

Cette application affiche les services web eux-mêmes. Elle ne copie ni ne redistribue
leurs données. Le fonctionnement de certaines fonctions peut dépendre des règles,
cookies, protections anti-bot ou évolutions des sites Flightradar24 et MarineTraffic.
