package fr.airseakids

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.*
import android.webkit.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private lateinit var webView: WebView
    private lateinit var timerText: TextView
    private var timer: CountDownTimer? = null
    private var remainingMs: Long = 0L
    private var currentUrl = ""
    private var parentDialog: Dialog? = null

    private val prefs by lazy { getSharedPreferences("airsea", MODE_PRIVATE) }

    private val allowedHosts = setOf(
        "flightradar24.com", "www.flightradar24.com",
        "marinetraffic.com", "www.marinetraffic.com"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        setupUi()
        startOrRestoreTimer()
        enterKioskIfPossible()
    }

    private fun setupUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 24, 32))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 8, 18, 8)
        }

        fun button(label: String, action: () -> Unit): Button =
            Button(this).apply {
                text = label
                textSize = 16f
                setOnClickListener { action() }
            }

        top.addView(button("✈️ AVIONS") {
            if (hasTime()) loadUrl("https://www.flightradar24.com/")
        })
        top.addView(button("🚢 NAVIRES") {
            if (hasTime()) loadUrl("https://www.marinetraffic.com/")
        })
        top.addView(button("←") { if (webView.canGoBack()) webView.goBack() })
        top.addView(button("↻") { webView.reload() })

        timerText = TextView(this).apply {
            textColor = Color.WHITE
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(12, 0, 12, 0)
            setOnLongClickListener {
                showParentDialog()
                true
            }
        }
        top.addView(timerText, LinearLayout.LayoutParams(0, -1, 1f))

        val parent = button("PARENT") { showParentDialog() }
        top.addView(parent)

        root.addView(top, LinearLayout.LayoutParams(-1, 62))

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.setSupportZoom(true)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val host = request?.url?.host?.lowercase(Locale.US) ?: return true
                    return !isAllowedHost(host)
                }

                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return true
                    val host = uri.host?.lowercase(Locale.US) ?: return true
                    return !isAllowedHost(host)
                }
            }
            webChromeClient = WebChromeClient()
        }

        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        loadUrl("https://www.flightradar24.com/")
    }

    private fun isAllowedHost(host: String): Boolean {
        return allowedHosts.any { host == it || host.endsWith(".$it") }
    }

    private fun loadUrl(url: String) {
        currentUrl = url
        webView.loadUrl(url)
    }

    private fun startOrRestoreTimer() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val savedDay = prefs.getString("day", "")
        if (savedDay != today) {
            val minutes = prefs.getInt("dailyMinutes", 45)
            remainingMs = minutes * 60_000L
            prefs.edit().putString("day", today).apply()
        } else {
            remainingMs = prefs.getLong("remainingMs", prefs.getInt("dailyMinutes", 45) * 60_000L)
        }

        timer?.cancel()
        timer = object : CountDownTimer(remainingMs, 1000) {
            override fun onTick(ms: Long) {
                remainingMs = ms
                prefs.edit().putLong("remainingMs", ms).apply()
                updateTimer(ms)
            }

            override fun onFinish() {
                remainingMs = 0
                prefs.edit().putLong("remainingMs", 0).apply()
                updateTimer(0)
                lockChildScreen()
            }
        }.start()
    }

    private fun updateTimer(ms: Long) {
        val total = ms / 1000
        val min = total / 60
        val sec = total % 60
        timerText.text = String.format(Locale.US, "⏱ %02d:%02d", min, sec)
    }

    private fun hasTime() = remainingMs > 0

    private fun lockChildScreen() {
        webView.stopLoading()
        webView.loadData(
            "<html><body style='background:#101820;color:white;text-align:center;font-family:sans-serif;padding-top:20%;'>" +
            "<h1>Temps terminé</h1><p>Demande à un parent de déverrouiller.</p></body></html>",
            "text/html", "UTF-8", null
        )
    }

    private fun showParentDialog() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Code PIN"
        }

        AlertDialog.Builder(this)
            .setTitle("Accès parent")
            .setMessage("Entre le code PIN")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                if (input.text.toString() == prefs.getString("pin", "1234")) {
                    showParentSettings()
                } else {
                    Toast.makeText(this, "Code incorrect", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showParentSettings() {
        val minutes = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "Minutes par jour"
            setText(prefs.getInt("dailyMinutes", 45).toString())
        }

        AlertDialog.Builder(this)
            .setTitle("Réglages parent")
            .setMessage("Durée quotidienne")
            .setView(minutes)
            .setPositiveButton("Enregistrer") { _, _ ->
                val value = minutes.text.toString().toIntOrNull()?.coerceIn(1, 240) ?: 45
                prefs.edit()
                    .putInt("dailyMinutes", value)
                    .putLong("remainingMs", value * 60_000L)
                    .apply()
                startOrRestoreTimer()
                Toast.makeText(this, "Durée : $value min", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Changer le PIN") { _, _ -> changePin() }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun changePin() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Nouveau PIN"
        }
        AlertDialog.Builder(this)
            .setTitle("Nouveau PIN")
            .setView(input)
            .setPositiveButton("Enregistrer") { _, _ ->
                val p = input.text.toString()
                if (p.length >= 4) {
                    prefs.edit().putString("pin", p).apply()
                } else {
                    Toast.makeText(this, "PIN de 4 chiffres minimum", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun enterKioskIfPossible() {
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        try {
            if (dpm.isLockTaskPermitted(packageName)) {
                startLockTask()
            }
        } catch (_: Exception) { }
    }

    private fun lockChildScreenKiosk() {
        enterKioskIfPossible()
        lockChildScreen()
    }

    override fun onBackPressed() {
        if (webView.canGoBack() && hasTime()) {
            webView.goBack()
        }
    }

    override fun onPause() {
        super.onPause()
        prefs.edit().putLong("remainingMs", remainingMs).apply()
    }
}
