package fr.airseakids

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
